from flask import Flask, request, jsonify, render_template
from flask_cors import CORS
from sumy.parsers.plaintext import PlaintextParser
from sumy.nlp.tokenizers import Tokenizer
from sumy.summarizers.lsa import LsaSummarizer

app = Flask(__name__, static_url_path='/static')
CORS(app)  # To enable CORS for all routes

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/summarize', methods=['POST'])
def summarize():
    data = request.json
    text = data.get('text', '')

    LANGUAGE = "english"
    SENTENCES_COUNT = 3  # Number of sentences in the summary

    parser = PlaintextParser.from_string(text, Tokenizer(LANGUAGE))
    summarizer = LsaSummarizer()
    summary = summarizer(parser.document, SENTENCES_COUNT)

    # Join the summarized sentences into a single string
    summary_text = ' '.join(str(sentence) for sentence in summary)

    return jsonify({'summary': summary_text})

if __name__ == '__main__':
    app.run(debug=True)
